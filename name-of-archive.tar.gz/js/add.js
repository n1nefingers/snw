/**
 * Created by lofms on 2018-04-19.
 */
var something = function() {
    console.log('something')}

hej = $( ".myCssClass" );

console.log(hej)